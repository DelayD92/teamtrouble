create trigger GENRE_ON_INSERT
  before insert
  on GENRE
  for each row
  BEGIN
    SELECT genre_sequence.nextval INTO :new.Id FROM dual;
  END;
/

