create trigger PERSON_ON_INSERT
  before insert
  on PERSON
  for each row
  BEGIN
    SELECT person_sequence.nextval INTO :new.Id FROM dual;
  END;
/

