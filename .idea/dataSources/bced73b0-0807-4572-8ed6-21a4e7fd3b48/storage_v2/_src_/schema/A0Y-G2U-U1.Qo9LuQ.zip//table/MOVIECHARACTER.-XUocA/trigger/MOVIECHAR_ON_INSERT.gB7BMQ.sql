create trigger MOVIECHAR_ON_INSERT
  before insert
  on MOVIECHARACTER
  for each row
  BEGIN
    SELECT moviechar_sequence.nextval INTO :new.Id FROM dual;
  END;
/

