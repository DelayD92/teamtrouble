create trigger MOVIE_ON_INSERT
  before insert
  on MOVIE
  for each row
  BEGIN
    SELECT movie_sequence.nextval INTO :new.Id FROM dual;
  END;
/

